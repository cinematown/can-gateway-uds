#ifndef PROTOCOL_IDS_H
#define PROTOCOL_IDS_H

/* --- 실제 측정된 CAN ID 정의 (Board A -> Board B -> Board C) --- */
/* 이미지에서 확인된 실제 ID로 교체 */
#define CAN_ID_RPM_DATA             0x280  // RPM 데이터 (바늘 제어)
#define CAN_ID_SPEED_DATA           0x1A0  // Speed 데이터 (바늘 및 카운터 제어)

/* --- UDS 진단 ID 정의 (Board B <-> Board C) --- */
/* 통상적인 ISO 15765-4 규격 ID */
#define CAN_ID_UDS_REQ_BOARD_B      0x7E0  // 진단기 -> 제어기 (요청)
#define CAN_ID_UDS_RESP_BOARD_B     0x7E8  // 제어기 -> 진단기 (응답)

/* --- UDS DID (Data Identifier) 정의 --- */
/* 이미지 명세와 코드의 가독성을 고려한 정의 */
#define UDS_DID_VIN                 0xF190 // VIN (Vehicle Identification Number)
#define UDS_DID_RPM                 0xF40C // 엔진 회전수 (데이터 위치: 0x280의 data[2:3])
#define UDS_DID_SPEED               0xF40D // 차량 속도 (데이터 위치: 0x1A0의 data[2:3])
#define UDS_DID_COOLANT             0xF40E // 냉각수 온도

/* 추가 가능한 DID (이미지 우선순위 표 참고) */
#define UDS_DID_HW_VERSION          0xF191 // HW 번호
#define UDS_DID_SW_VERSION          0xF189 // SW 버전
#define UDS_DID_SERIAL_NUMBER       0xF18C // ECU 시리얼 번호

#endif