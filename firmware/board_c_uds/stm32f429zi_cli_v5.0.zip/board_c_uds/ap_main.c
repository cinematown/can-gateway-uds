#include "main.h"
#include "cmsis_os2.h"
#include "uart.h"
#include "cli.h"
#include "can_bsp.h"
#include "signal_db.h"
#include "uds_server.h"
#include "cli_cmd.h"

/*
 * freertos.c의 __weak UDSMainTask()를 Board C 폴더에서 오버라이딩합니다.
 * main.c, Core/Src/freertos.c, common/*.c는 수정하지 않습니다.
 */
void UDSMainTask(void *argument)
{
    (void)argument;

    uartInit();
    cliInit();
    CAN_BSP_Init();

    SignalDB_Init();
    UDS_Server_Init();
    CLI_CMD_Init();

    cliPrintf("\r\n========================================\r\n");
    cliPrintf(" Board C - UDS Diagnostic Server Ready\r\n");
    cliPrintf(" Role: CAN2 signal store + UDS response\r\n");
    cliPrintf(" Req : 0x%03X, Resp: 0x%03X\r\n", CAN_ID_UDS_REQ_BOARD_B, CAN_ID_UDS_RESP_BOARD_B);
    cliPrintf(" Try : uds_info, signal, read_did F40C\r\n");
    cliPrintf("========================================\r\n");
    cliPrintf("CLI > ");

    CAN_RxMessage_t msg;

    for (;;)
    {
        cliMain();

        while (CAN_BSP_Read(&msg, 0u))
        {
            /* 1. Gateway가 넘겨준 RPM/Speed/Coolant 값을 저장 */
            (void)SignalDB_OnCanRx(&msg);

            /* 2. 사용자가 UDS로 물어보면 저장된 값을 응답 */
            UDS_Server_OnCanRx(&msg);
        }

        osDelay(1u);
    }
}
