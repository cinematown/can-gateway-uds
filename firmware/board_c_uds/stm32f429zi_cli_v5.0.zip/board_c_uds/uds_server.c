#include "uds_server.h"
#include "signal_db.h"
#include "cli.h"
#include <string.h>

/*
 * Board C - UDS Diagnostic Server
 * * 역할:
 * 1) Tester/Gateway로부터 UDS 요청 수신 (Single Frame 지원)
 * 2) DID 요청에 따라 SignalDB의 최신 차량 신호값 읽기
 * 3) UDS 응답을 CAN으로 송신 (Multi-frame/ISO-TP 지원)
 */

/* -------------------------------------------------------------------------- */
/* ISO-TP PCI 및 상수 정의                            */
/* -------------------------------------------------------------------------- */
#define ISOTP_TYPE_MASK     0xF0u
#define ISOTP_SF            0x00u   /* Single Frame */
#define ISOTP_FF            0x10u   /* First Frame */
#define ISOTP_CF            0x20u   /* Consecutive Frame */
#define ISOTP_FC            0x30u   /* Flow Control */
#define ISOTP_FC_CTS        0x30u   /* Flow Control: Continue To Send */

/* -------------------------------------------------------------------------- */
/* 전역 변수 (Internal State)                        */
/* -------------------------------------------------------------------------- */
static UDS_Payload_t g_pending_resp;    /* Multi-frame 응답 데이터 저장 */
static uint16_t      g_pending_offset;  /* 현재 전송 위치 */
static uint8_t       g_pending_sn;      /* Sequence Number */
static bool          g_waiting_fc;      /* Flow Control 대기 상태 */

static const char g_vin[17] = "WVWZZZ1KZCW296899"; /* 고정 VIN 데이터 */

/* -------------------------------------------------------------------------- */
/* 하위 수준 유틸리티 함수                           */
/* -------------------------------------------------------------------------- */

/* UDS Negative Response 데이터 구성 */
static void uds_make_negative(uint8_t sid, uint8_t nrc, UDS_Payload_t *resp)
{
    resp->data[0] = UDS_NEG_RESP;
    resp->data[1] = sid;
    resp->data[2] = nrc;
    resp->len     = 3u;
}

/* CAN 물리 계층 송신 호출 */
static HAL_StatusTypeDef uds_can_send(uint8_t data[8])
{
    return CAN_BSP_Send(CAN_ID_UDS_RESP_BOARD_B, data, 8u);
}

/* -------------------------------------------------------------------------- */
/* ISO-TP 전송 로직                                  */
/* -------------------------------------------------------------------------- */

/* 7바이트 이하 응답: Single Frame */
static bool uds_send_single_frame(const UDS_Payload_t *payload)
{
    uint8_t tx[8] = {0};

    if (payload == NULL || payload->len > 7u)
    {
        return false;
    }

    tx[0] = (uint8_t)payload->len;
    if (payload->len > 0u)
    {
        memcpy(&tx[1], payload->data, payload->len);
    }

    return (uds_can_send(tx) == HAL_OK);
}

/* 8바이트 이상 응답 시작: First Frame */
static bool uds_send_first_frame(const UDS_Payload_t *payload)
{
    uint8_t tx[8] = {0};

    if (payload == NULL || payload->len <= 7u || payload->len > UDS_PAYLOAD_MAX_LEN)
    {
        return false;
    }

    /* PCI + 전체 길이 (12-bit) */
    tx[0] = (uint8_t)(0x10u | ((payload->len >> 8) & 0x0Fu));
    tx[1] = (uint8_t)(payload->len & 0xFFu);

    /* 최초 6바이트 데이터 복사 */
    memcpy(&tx[2], payload->data, 6u);

    /* 후속 전송을 위한 상태 업데이트 */
    g_pending_resp   = *payload;
    g_pending_offset = 6u;
    g_pending_sn     = 1u;
    g_waiting_fc     = true;

    return (uds_can_send(tx) == HAL_OK);
}

/* Flow Control 수신 후 나머지 데이터 전송: Consecutive Frame */
static bool uds_send_consecutive_frames(uint8_t block_size)
{
    uint8_t sent_in_block = 0u;

    if (!g_waiting_fc)
    {
        return false;
    }

    while (g_pending_offset < g_pending_resp.len)
    {
        uint8_t tx[8] = {0};
        uint16_t remain = g_pending_resp.len - g_pending_offset;
        uint8_t copy_len = (remain > 7u) ? 7u : (uint8_t)remain;

        /* PCI + Sequence Number */
        tx[0] = (uint8_t)(0x20u | (g_pending_sn & 0x0Fu));
        memcpy(&tx[1], &g_pending_resp.data[g_pending_offset], copy_len);

        if (uds_can_send(tx) != HAL_OK)
        {
            return false;
        }

        g_pending_offset += copy_len;
        g_pending_sn = (uint8_t)((g_pending_sn + 1u) & 0x0Fu);
        sent_in_block++;

        /* Block Size 체크 (0이 아니면 지정된 개수 전송 후 다시 FC 대기) */
        if (block_size != 0u && sent_in_block >= block_size && g_pending_offset < g_pending_resp.len)
        {
            g_waiting_fc = true;
            return true;
        }
    }

    /* 전송 완료 상태 초기화 */
    g_waiting_fc     = false;
    g_pending_offset = 0u;
    g_pending_sn     = 1u;

    return true;
}

/* 길이에 따른 프레임 타입 자동 선택 송신 */
static bool uds_send_payload(const UDS_Payload_t *payload)
{
    if (payload == NULL) return false;
    if (payload->len <= 7u) return uds_send_single_frame(payload);
    return uds_send_first_frame(payload);
}

/* -------------------------------------------------------------------------- */
/* UDS 서비스 핸들러                                 */
/* -------------------------------------------------------------------------- */

/* SID 0x22: ReadDataByIdentifier */
static bool uds_handle_read_did(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp)
{
    if (req_len != 3u)
    {
        uds_make_negative(UDS_SID_READ_DID, UDS_NRC_INCORRECT_LENGTH, resp);
        return true;
    }

    uint16_t did = ((uint16_t)req[1] << 8) | req[2];
    resp->data[0] = UDS_POS_READ_DID;
    resp->data[1] = req[1];
    resp->data[2] = req[2];

    switch (did)
    {
        case UDS_DID_VIN:
            memcpy(&resp->data[3], g_vin, 17u);
            resp->len = 20u;
            break;

        case UDS_DID_RPM: {
            uint16_t rpm = SignalDB_GetRPM();
            resp->data[3] = (uint8_t)((rpm >> 8) & 0xFFu);
            resp->data[4] = (uint8_t)(rpm & 0xFFu);
            resp->len = 5u;
            break;
        }

        case UDS_DID_SPEED: {
            uint16_t speed = SignalDB_GetSpeed();
            resp->data[3] = (uint8_t)((speed >> 8) & 0xFFu);
            resp->data[4] = (uint8_t)(speed & 0xFFu);
            resp->len = 5u;
            break;
        }

        case UDS_DID_COOLANT:
            resp->data[3] = (uint8_t)SignalDB_GetCoolantTemp();
            resp->len = 4u;
            break;

        default:
            uds_make_negative(UDS_SID_READ_DID, UDS_NRC_REQUEST_OUT_OF_RANGE, resp);
            break;
    }
    return true;
}

/* SID 0x10: DiagnosticSessionControl */
static bool uds_handle_session(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp)
{
    if (req_len != 2u)
    {
        uds_make_negative(UDS_SID_DIAGNOSTIC_SESSION_CONTROL, UDS_NRC_INCORRECT_LENGTH, resp);
        return true;
    }

    if (req[1] != 0x01u && req[1] != 0x03u)
    {
        uds_make_negative(UDS_SID_DIAGNOSTIC_SESSION_CONTROL, UDS_NRC_SUBFUNC_NOT_SUPPORTED, resp);
        return true;
    }

    resp->data[0] = UDS_POS_DIAGNOSTIC_SESSION_CONTROL;
    resp->data[1] = req[1];
    resp->len     = 2u;
    return true;
}

/* SID 0x3E: TesterPresent */
static bool uds_handle_tester_present(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp)
{
    if (req_len != 2u)
    {
        uds_make_negative(UDS_SID_TESTER_PRESENT, UDS_NRC_INCORRECT_LENGTH, resp);
        return true;
    }

    if (req[1] == 0x80u) /* Positive Response 억제 요청 */
    {
        resp->len = 0u;
        return true;
    }

    if (req[1] != 0x00u)
    {
        uds_make_negative(UDS_SID_TESTER_PRESENT, UDS_NRC_SUBFUNC_NOT_SUPPORTED, resp);
        return true;
    }

    resp->data[0] = UDS_POS_TESTER_PRESENT;
    resp->data[1] = 0x00u;
    resp->len     = 2u;
    return true;
}

/* SID 0x19: ReadDTCInformation */
static bool uds_handle_read_dtc(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp)
{
    if (req_len != 3u)
    {
        uds_make_negative(UDS_SID_READ_DTC_INFORMATION, UDS_NRC_INCORRECT_LENGTH, resp);
        return true;
    }

    if (req[1] != 0x02u) /* reportDTCByStatusMask만 지원 */
    {
        uds_make_negative(UDS_SID_READ_DTC_INFORMATION, UDS_NRC_SUBFUNC_NOT_SUPPORTED, resp);
        return true;
    }

    resp->data[0] = UDS_POS_READ_DTC_INFORMATION;
    resp->data[1] = 0x02u;
    resp->data[2] = req[2];
    resp->len     = 3u;
    return true;
}

/* -------------------------------------------------------------------------- */
/* UDS 서버 공개 API                                 */
/* -------------------------------------------------------------------------- */

/* 서버 상태 초기화 */
void UDS_Server_Init(void)
{
    memset(&g_pending_resp, 0, sizeof(g_pending_resp));
    g_pending_offset = 0u;
    g_pending_sn     = 1u;
    g_waiting_fc     = false;
}

/* 서비스별 핸들러 분기 */
bool UDS_Server_ProcessPayload(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp)
{
    if (req == NULL || resp == NULL || req_len == 0u)
    {
        return false;
    }

    memset(resp, 0, sizeof(*resp));

    switch (req[0])
    {
        case UDS_SID_DIAGNOSTIC_SESSION_CONTROL: 
            return uds_handle_session(req, req_len, resp);
        case UDS_SID_READ_DTC_INFORMATION:       
            return uds_handle_read_dtc(req, req_len, resp);
        case UDS_SID_READ_DID:                   
            return uds_handle_read_did(req, req_len, resp);
        case UDS_SID_TESTER_PRESENT:             
            return uds_handle_tester_present(req, req_len, resp);
        default:
            /* 지원하지 않는 서비스인 경우 Negative Response 전송 */
            uds_make_negative(req[0], UDS_NRC_SERVICE_NOT_SUPPORTED, resp);
            return true;
    }
}

/* CAN 수신 콜백 엔트리 포인트 */
void UDS_Server_OnCanRx(const CAN_RxMessage_t *msg)
{
    if (msg == NULL || msg->id != CAN_ID_UDS_REQ_BOARD_B || msg->dlc == 0u)
    {
        return;
    }

    uint8_t pci_type = msg->data[0] & ISOTP_TYPE_MASK;
    UDS_Payload_t resp;

    /* 1. Flow Control 수신 시: 대기 중인 Multi-frame 전송 재개 */
    if (pci_type == ISOTP_FC)
    {
        uint8_t fs = msg->data[0] & 0x0Fu;
        if (fs == 0x00u) /* CTS (Continue To Send) */
        {
            (void)uds_send_consecutive_frames(msg->data[1]);
        }
        return;
    }

    /* 2. 요청 수신 처리 (현재는 Single Frame 요청만 지원) */
    if (pci_type != ISOTP_SF)
    {
        uds_make_negative(0x00, UDS_NRC_INCORRECT_LENGTH, &resp);
        (void)uds_send_payload(&resp);
        return;
    }

    uint8_t payload_len = msg->data[0] & 0x0Fu;
    if (payload_len == 0u || payload_len > 7u || payload_len > (msg->dlc - 1u))
    {
        uds_make_negative(0x00, UDS_NRC_INCORRECT_LENGTH, &resp);
        (void)uds_send_payload(&resp);
        return;
    }

    /* 3. UDS 데이터 처리 및 응답 전송 */
    if (UDS_Server_ProcessPayload(&msg->data[1], payload_len, &resp))
    {
        if (resp.len > 0u)
        {
            (void)uds_send_payload(&resp);
        }
    }
}