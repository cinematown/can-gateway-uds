#ifndef SIGNAL_DB_H
#define SIGNAL_DB_H

#include <stdint.h>
#include <stdbool.h>
#include "can_bsp.h"

/*
 * SignalDB = Board C 내부의 간단한 DBC 역할
 * Gateway(Board B)가 CAN2 Diagnostic Bus로 넘겨준 값을 저장합니다.
 *
 * 기본 데이터 형식:
 *   CAN_ID_DASHBOARD_CTRL 또는 CAN_ID_ENGINE_DATA
 *   Byte0~1 : RPM, big-endian
 *   Byte2~3 : Speed, big-endian
 *   Byte4   : Coolant temperature, uint8_t/int8_t
 */

typedef struct
{
    uint16_t rpm;
    uint16_t speed;
    int8_t coolant_temp;
    uint32_t last_update_ms;
    uint32_t rx_count;
} SignalDB_t;

void SignalDB_Init(void);
bool SignalDB_OnCanRx(const CAN_RxMessage_t *msg);

uint16_t SignalDB_GetRPM(void);
uint16_t SignalDB_GetSpeed(void);
int8_t   SignalDB_GetCoolantTemp(void);
uint32_t SignalDB_GetRxCount(void);
uint32_t SignalDB_GetLastUpdateMs(void);

void SignalDB_SetRPM(uint16_t rpm);
void SignalDB_SetSpeed(uint16_t speed);
void SignalDB_SetCoolantTemp(int8_t temp);
void SignalDB_GetSnapshot(SignalDB_t *out);

#endif /* SIGNAL_DB_H */
