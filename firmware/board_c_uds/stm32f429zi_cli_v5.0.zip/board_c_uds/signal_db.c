#include "signal_db.h"
#include "protocol_ids.h"
#include "main.h"
#include <string.h>

/**
 * @file signal_db.c
 * @brief 차량 주요 신호 데이터 관리 및 캐싱 모듈
 * * 역할:
 * 1) CAN 버스로부터 수신된 Raw 데이터를 파싱하여 물리 값으로 변환 저장
 * 2) UDS 서버나 CLI 등 타 모듈에서 최신 데이터에 접근할 수 있도록 인터페이스 제공
 * 3) 데이터 업데이트 시간 및 수신 통계 관리
 */

/* -------------------------------------------------------------------------- */
/* 내부 전역 변수 (Static State)                                              */
/* -------------------------------------------------------------------------- */
static SignalDB_t g_signal;

/* -------------------------------------------------------------------------- */
/* 초기화 및 수신 처리                                                        */
/* -------------------------------------------------------------------------- */

/**
 * @brief SignalDB 모듈 초기화
 * @details 메모리를 0으로 초기화하고, 통신 연결 전 테스트를 위한 기본값을 설정합니다.
 */
void SignalDB_Init(void)
{
    memset(&g_signal, 0, sizeof(g_signal));

    /* 초기 기본값: CAN 데이터가 아직 없어도 UDS/UI 테스트가 가능하도록 설정 */
    g_signal.rpm            = 1234u;  // 초기 RPM: 1234
    g_signal.speed          = 56u;    // 초기 속도: 56 km/h
    g_signal.coolant_temp   = 85;     // 초기 냉각수 온도: 85도
    g_signal.last_update_ms = HAL_GetTick();
}

/**
 * @brief CAN 수신 콜백에서 호출되는 데이터 파싱 함수
 * @param msg 수신된 CAN 메시지 포인터
 * @return bool 데이터 업데이트 성공 여부
 */
bool SignalDB_OnCanRx(const CAN_RxMessage_t *msg)
{
    if (msg == NULL)
    {
        return false;
    }

    /* * 수신 ID 필터링: 
     * Board B Gateway가 전달하는 계기판 데이터(DASHBOARD_CTRL)와 
     * 기존 엔진 데이터(ENGINE_DATA) 모두 수용 
     */
    if (msg->id != CAN_ID_DASHBOARD_CTRL && msg->id != CAN_ID_ENGINE_DATA)
    {
        return false;
    }

    /* 최소 데이터 길이 검사: RPM(2B) + Speed(2B) + Temp(1B) = 5Byte */
    if (msg->dlc < 5u)
    {
        return false;
    }

    /* * Raw 데이터 파싱 (Big Endian 구조 가정) 
     * data[0:1]: RPM
     * data[2:3]: Speed
     * data[4]:   Coolant Temp
     */
    g_signal.rpm            = ((uint16_t)msg->data[0] << 8) | msg->data[1];
    g_signal.speed          = ((uint16_t)msg->data[2] << 8) | msg->data[3];
    g_signal.coolant_temp   = (int8_t)msg->data[4];
    
    /* 관리 정보 업데이트 */
    g_signal.last_update_ms = HAL_GetTick();
    g_signal.rx_count++;

    return true;
}

/* -------------------------------------------------------------------------- */
/* 데이터 조회 API (Getters)                                                  */
/* -------------------------------------------------------------------------- */

uint16_t SignalDB_GetRPM(void)
{
    return g_signal.rpm;
}

uint16_t SignalDB_GetSpeed(void)
{
    return g_signal.speed;
}

int8_t SignalDB_GetCoolantTemp(void)
{
    return g_signal.coolant_temp;
}

uint32_t SignalDB_GetRxCount(void)
{
    return g_signal.rx_count;
}

uint32_t SignalDB_GetLastUpdateMs(void)
{
    return g_signal.last_update_ms;
}

/* -------------------------------------------------------------------------- */
/* 데이터 설정 및 유틸리티 API (Setters & Snapshots)                          */
/* -------------------------------------------------------------------------- */

void SignalDB_SetRPM(uint16_t rpm)
{
    g_signal.rpm = rpm;
    g_signal.last_update_ms = HAL_GetTick();
}

void SignalDB_SetSpeed(uint16_t speed)
{
    g_signal.speed = speed;
    g_signal.last_update_ms = HAL_GetTick();
}

void SignalDB_SetCoolantTemp(int8_t temp)
{
    g_signal.coolant_temp = temp;
    g_signal.last_update_ms = HAL_GetTick();
}

/**
 * @brief 현재 전체 신호 데이터의 복사본(스냅샷) 획득
 * @param out 복사받을 외부 구조체 포인터
 */
void SignalDB_GetSnapshot(SignalDB_t *out)
{
    if (out != NULL)
    {
        /* 구조체 전체 멤버를 메모리 복사 */
        *out = g_signal;
    }
}