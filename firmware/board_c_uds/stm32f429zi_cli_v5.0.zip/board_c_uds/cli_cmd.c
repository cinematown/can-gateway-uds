#include "cli_cmd.h"
#include "cli.h"
#include "uds_server.h"
#include "signal_db.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

static bool parse_hex16(const char *s, uint16_t *out)
{
    char *end = NULL;
    unsigned long v;

    if (s == NULL || out == NULL)
    {
        return false;
    }

    v = strtoul(s, &end, 16);
    if (*end != '\0' || v > 0xFFFFul)
    {
        return false;
    }

    *out = (uint16_t)v;
    return true;
}

static bool parse_u16_dec(const char *s, uint16_t *out)
{
    char *end = NULL;
    unsigned long v;

    if (s == NULL || out == NULL)
    {
        return false;
    }

    v = strtoul(s, &end, 10);
    if (*end != '\0' || v > 0xFFFFul)
    {
        return false;
    }

    *out = (uint16_t)v;
    return true;
}

static void print_payload(const char *tag, const UDS_Payload_t *p)
{
    cliPrintf("%s", tag);
    for (uint16_t i = 0u; i < p->len; i++)
    {
        cliPrintf("%02X ", p->data[i]);
    }
    cliPrintf("\r\n");
}

static void cmd_uds_info(uint8_t argc, char *argv[])
{
    SignalDB_t s;
    (void)argc;
    (void)argv;

    SignalDB_GetSnapshot(&s);

    cliPrintf("\r\n[Board C - UDS Diagnostic Server]\r\n");
    cliPrintf("UDS Request  CAN ID : 0x%03X\r\n", CAN_ID_UDS_REQ_BOARD_B);
    cliPrintf("UDS Response CAN ID : 0x%03X\r\n", CAN_ID_UDS_RESP_BOARD_B);
    cliPrintf("Input signal CAN ID : 0x%03X or 0x%03X\r\n", CAN_ID_DASHBOARD_CTRL, CAN_ID_ENGINE_DATA);
    cliPrintf("DID F190 = VIN\r\n");
    cliPrintf("DID F40C = RPM\r\n");
    cliPrintf("DID F40D = Speed\r\n");
    cliPrintf("DID F40E = Coolant Temp\r\n");
    cliPrintf("Current RPM=%u, Speed=%u, Coolant=%d, RxCount=%lu\r\n",
              s.rpm, s.speed, s.coolant_temp, (unsigned long)s.rx_count);
}

static void cmd_signal(uint8_t argc, char *argv[])
{
    SignalDB_t s;
    (void)argc;
    (void)argv;

    SignalDB_GetSnapshot(&s);

    cliPrintf("[SignalDB]\r\n");
    cliPrintf("RPM     : %u\r\n", s.rpm);
    cliPrintf("Speed   : %u\r\n", s.speed);
    cliPrintf("Coolant : %d\r\n", s.coolant_temp);
    cliPrintf("RxCount : %lu\r\n", (unsigned long)s.rx_count);
    cliPrintf("Last ms : %lu\r\n", (unsigned long)s.last_update_ms);
}

static void cmd_set_signal(uint8_t argc, char *argv[])
{
    uint16_t rpm;
    uint16_t speed;
    char *end = NULL;
    long temp;

    if (argc != 4u)
    {
        cliPrintf("usage: set_signal <rpm> <speed> <coolant>\r\n");
        cliPrintf("ex   : set_signal 3000 100 90\r\n");
        return;
    }

    if (!parse_u16_dec(argv[1], &rpm) || !parse_u16_dec(argv[2], &speed))
    {
        cliPrintf("invalid rpm/speed\r\n");
        return;
    }

    temp = strtol(argv[3], &end, 10);
    if (*end != '\0' || temp < -128 || temp > 127)
    {
        cliPrintf("invalid coolant temp\r\n");
        return;
    }

    SignalDB_SetRPM(rpm);
    SignalDB_SetSpeed(speed);
    SignalDB_SetCoolantTemp((int8_t)temp);

    cliPrintf("Signal updated: RPM=%u Speed=%u Coolant=%ld\r\n", rpm, speed, temp);
}

static void cmd_read_did_local(uint8_t argc, char *argv[])
{
    uint16_t did;
    uint8_t req[3];
    UDS_Payload_t resp;

    if (argc != 2u || !parse_hex16(argv[1], &did))
    {
        cliPrintf("usage: read_did F40C\r\n");
        cliPrintf("ex   : read_did F40C / F40D / F40E / F190\r\n");
        return;
    }

    req[0] = UDS_SID_READ_DID;
    req[1] = (uint8_t)((did >> 8) & 0xFFu);
    req[2] = (uint8_t)(did & 0xFFu);

    cliPrintf("[LOCAL REQ] %02X %02X %02X\r\n", req[0], req[1], req[2]);

    if (UDS_Server_ProcessPayload(req, sizeof(req), &resp))
    {
        print_payload("[LOCAL RESP] ", &resp);
        if (resp.len > 7u)
        {
            cliPrintf("Note: CAN response will be ISO-TP multi-frame. Use Flow Control after First Frame.\r\n");
        }
    }
}

static void cmd_uds_raw_local(uint8_t argc, char *argv[])
{
    uint8_t req[7] = {0};
    UDS_Payload_t resp;

    if (argc < 2u || argc > 8u)
    {
        cliPrintf("usage: uds_raw 22 F4 0C\r\n");
        return;
    }

    for (uint8_t i = 1u; i < argc; i++)
    {
        uint16_t v;
        if (!parse_hex16(argv[i], &v) || v > 0xFFu)
        {
            cliPrintf("invalid byte: %s\r\n", argv[i]);
            return;
        }
        req[i - 1u] = (uint8_t)v;
    }

    if (UDS_Server_ProcessPayload(req, (uint8_t)(argc - 1u), &resp))
    {
        print_payload("[LOCAL RESP] ", &resp);
    }
}

void CLI_CMD_Init(void)
{
    cliAdd("uds_info", cmd_uds_info);
    cliAdd("signal", cmd_signal);
    cliAdd("set_signal", cmd_set_signal);
    cliAdd("read_did", cmd_read_did_local);
    cliAdd("uds_raw", cmd_uds_raw_local);
}
