#ifndef UDS_SERVER_H
#define UDS_SERVER_H

#include <stdint.h>
#include <stdbool.h>
#include "can_bsp.h"
#include "protocol_ids.h"

/* UDS Service IDs */
#define UDS_SID_DIAGNOSTIC_SESSION_CONTROL  0x10u
#define UDS_SID_READ_DTC_INFORMATION        0x19u
#define UDS_SID_READ_DID                    0x22u
#define UDS_SID_TESTER_PRESENT              0x3Eu

/* UDS Positive Response IDs */
#define UDS_POS_DIAGNOSTIC_SESSION_CONTROL  0x50u
#define UDS_POS_READ_DTC_INFORMATION        0x59u
#define UDS_POS_READ_DID                    0x62u
#define UDS_POS_TESTER_PRESENT              0x7Eu

/* Negative Response */
#define UDS_NEG_RESP                        0x7Fu
#define UDS_NRC_SERVICE_NOT_SUPPORTED       0x11u
#define UDS_NRC_SUBFUNC_NOT_SUPPORTED       0x12u
#define UDS_NRC_INCORRECT_LENGTH            0x13u
#define UDS_NRC_REQUEST_OUT_OF_RANGE        0x31u

#define UDS_PAYLOAD_MAX_LEN                 64u

/* 필요 시 프로젝트 DID 이름 보정 */
#ifndef UDS_DID_TEMP
#define UDS_DID_TEMP                        0xF40Eu
#endif

/* 보고서에서 Coolant라고 부르기 위한 별칭 */
#define UDS_DID_COOLANT                     UDS_DID_TEMP

typedef struct
{
    uint8_t data[UDS_PAYLOAD_MAX_LEN];
    uint16_t len;
} UDS_Payload_t;

void UDS_Server_Init(void);
void UDS_Server_OnCanRx(const CAN_RxMessage_t *msg);
bool UDS_Server_ProcessPayload(const uint8_t *req, uint8_t req_len, UDS_Payload_t *resp);

#endif /* UDS_SERVER_H */
